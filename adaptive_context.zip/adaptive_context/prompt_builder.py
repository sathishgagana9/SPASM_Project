class PromptBuilder:

    def __init__(self):
        pass

    def build(
        self,
        persona,
        current_message,
        selected_context,
        graph_context,
        analysis,
        importance,
        risk
    ):

        # -----------------------------
        # Persona
        # -----------------------------

        persona_section = f"""
ROLE:
{persona['role']}

TONE:
{persona['tone']}

GOAL:
{persona['goal']}
"""

        # -----------------------------
        # Previous Conversation
        # -----------------------------

        context_text = ""

        if len(selected_context) == 0:

            context_text = "No previous conversation."

        else:

            for item in selected_context:

                context_text += f"{item['speaker']}: {item['message']}\n"

        # -----------------------------
        # Memory Graph
        # -----------------------------

        graph_text = ""

        if len(graph_context) == 0:

            graph_text = "No memory."

        else:

            for item in graph_context:

                graph_text += f"- {item}\n"

        # -----------------------------
        # Final Prompt
        # -----------------------------

        prompt = f"""
You are acting ONLY as the following persona.

====================================================
PERSONA
====================================================

{persona_section}

====================================================
CURRENT ANALYSIS
====================================================

Category : {analysis['category']}
Intent   : {analysis['intent']}
Emotion  : {analysis['emotion']}
Urgency  : {analysis['urgency']}
Domain   : {analysis['domain']}
Importance : {importance['importance']}
Risk : {risk['risk']}

====================================================
MEMORY
====================================================

{graph_text}

====================================================
CONVERSATION
====================================================

{context_text}

====================================================
CURRENT USER MESSAGE
====================================================

{current_message}

====================================================
VERY IMPORTANT RULES
====================================================

1. NEVER change your persona.

2. NEVER answer as another profession.

3. If your role is Doctor,
   answer ONLY medical questions.

4. If your role is Teacher,
   answer ONLY educational questions.

5. If your role is Lawyer,
   answer ONLY legal questions.

6. If the user asks something outside your expertise:

   DO NOT answer it.

   Instead reply:

   "As a {persona['role']}, this topic is outside my expertise. I recommend consulting an appropriate expert."

7. Never pretend to know another profession.

8. Maintain the selected tone.

9. Use previous conversation when useful.

10. Give short professional answers.

Return ONLY the assistant response.
"""

        return prompt


# ---------------------------------------------------
# TEST
# ---------------------------------------------------

if __name__ == "__main__":

    builder = PromptBuilder()

    persona = {
        "role": "Doctor",
        "tone": "Professional",
        "goal": "Help patients"
    }

    analysis = {
        "category": "Question",
        "intent": "Medical Advice",
        "emotion": "Concerned",
        "urgency": "Medium",
        "domain": "Healthcare"
    }

    importance = {
        "importance": 0.95
    }

    risk = {
        "risk": "Medium"
    }

    graph = []

    context = []

    print(
        builder.build(
            persona,
            "Can you explain mathematics?",
            context,
            graph,
            analysis,
            importance,
            risk
        )
    )