import json


class DecisionEngine:

    def __init__(self):

        self.importance_threshold = 0.60
        self.risk_threshold = "High"
        self.stability_threshold = 0.90

    # ------------------------------------------------
    # Decide System Actions
    # ------------------------------------------------

    def decide(

        self,

        analysis,

        importance,

        risk,

        graph_context,

        stability=None

    ):

        actions = {

            "use_memory": False,

            "use_graph": False,

            "need_clarification": False,

            "repair_persona": False,

            "optimize_response": False

        }

        # --------------------------------------
        # Memory Retrieval
        # --------------------------------------

        if importance["importance"] >= self.importance_threshold:

            actions["use_memory"] = True

        # --------------------------------------
        # Graph Retrieval
        # --------------------------------------

        if len(graph_context) > 0:

            actions["use_graph"] = True

        # --------------------------------------
        # Clarification
        # --------------------------------------

        if analysis["confidence"] < 0.60:

            actions["need_clarification"] = True

        # --------------------------------------
        # Risk
        # --------------------------------------

        if risk["risk"] in [

            "High",

            "Critical"

        ]:

            actions["optimize_response"] = True

        # --------------------------------------
        # Persona Repair
        # --------------------------------------

        if stability is not None:

            if stability < self.stability_threshold:

                actions["repair_persona"] = True

        return actions


# ------------------------------------------------------
# TEST
# ------------------------------------------------------

if __name__ == "__main__":

    engine = DecisionEngine()

    analysis = {

        "confidence":0.95

    }

    importance = {

        "importance":0.91

    }

    risk = {

        "risk":"High"

    }

    graph = [

        "Diabetes"

    ]

    actions = engine.decide(

        analysis,

        importance,

        risk,

        graph,

        stability=0.82

    )

    print(actions)