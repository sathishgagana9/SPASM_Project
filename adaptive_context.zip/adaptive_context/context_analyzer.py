import json
import os
import re
import sys

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from scripts.llm import generate


class ContextAnalyzer:

    def __init__(self):
        pass

    def analyze(self, persona, message):

        # ----------------------------------------
        # Quick Rule Based Detection
        # ----------------------------------------

        msg = message.lower().strip()

        greetings = [
            "hi",
            "hello",
            "hey",
            "good morning",
            "good evening",
            "hello doctor",
            "hi doctor"
        ]

        if msg in greetings:

            return {

                "category": "Greeting",

                "intent": "Greeting",

                "emotion": "Neutral",

                "urgency": "Low",

                "domain": "General",

                "entities": [],

                "keywords": [],

                "dependency": False,

                "novel_information": False,

                "persona_match": 1.0,

                "confidence": 1.0

            }

        prompt = f"""
You are an expert Context Analysis Engine.

Your ONLY job is to analyze the user's message.

Never answer the user.

--------------------------------------------------

PERSONA

Role:
{persona["role"]}

Goal:
{persona["goal"]}

--------------------------------------------------

USER MESSAGE

{message}

--------------------------------------------------

Return ONLY JSON.

Schema

{{
    "category":"",
    "intent":"",
    "emotion":"",
    "urgency":"",
    "domain":"",
    "entities":[],
    "keywords":[],
    "dependency":false,
    "novel_information":true,
    "persona_match":0.0,
    "confidence":0.0
}}

--------------------------------------------------

Allowed Categories

Greeting
Question
Complaint
Medical History
User Goal
Request
Small Talk
Information

--------------------------------------------------

Allowed Intent

Greeting
Seek Medical Advice
Request Explanation
Ask Information
Report Symptom
Provide Information
Casual Conversation

Never invent new intent names.

--------------------------------------------------

Allowed Domains

Healthcare
Education
Mathematics
Programming
Law
Travel
Finance
General

Choose only one.

--------------------------------------------------

Emotion

Neutral
Happy
Concerned
Angry
Sad

--------------------------------------------------

Urgency

Low
Medium
High
Critical

--------------------------------------------------

Examples

hello doctor

{{
"category":"Greeting",
"intent":"Greeting",
"emotion":"Neutral",
"urgency":"Low",
"domain":"General"
}}

I have diabetes

{{
"category":"Medical History",
"intent":"Report Symptom",
"emotion":"Neutral",
"urgency":"Medium",
"domain":"Healthcare"
}}

Can you explain mathematics?

{{
"category":"Question",
"intent":"Request Explanation",
"emotion":"Neutral",
"urgency":"Low",
"domain":"Mathematics"
}}

Return ONLY JSON.
"""

        response = generate(prompt)

                # ----------------------------------------
        # Clean LLM Response
        # ----------------------------------------

        response = response.strip()

        response = re.sub(r"^```json", "", response)
        response = re.sub(r"^```", "", response)
        response = re.sub(r"```$", "", response)

        response = response.strip()

        # ----------------------------------------
        # Parse JSON
        # ----------------------------------------

        try:

            result = json.loads(response)

        except Exception:

            print("\n==============================")
            print("Context Analyzer JSON Error")
            print("==============================")
            print(response)
            print("==============================")

            result = {}

        # ----------------------------------------
        # Default Values
        # ----------------------------------------

        defaults = {

            "category": "Unknown",

            "intent": "Ask Information",

            "emotion": "Neutral",

            "urgency": "Low",

            "domain": "General",

            "entities": [],

            "keywords": [],

            "dependency": False,

            "novel_information": True,

            "persona_match": 0.90,

            "confidence": 0.90

        }

        # ----------------------------------------
        # Fill Missing Keys
        # ----------------------------------------

        for key, value in defaults.items():

            if key not in result:

                result[key] = value

        # ----------------------------------------
        # Type Safety
        # ----------------------------------------

        if not isinstance(result["entities"], list):

            result["entities"] = []

        if not isinstance(result["keywords"], list):

            result["keywords"] = []

        try:

            result["persona_match"] = float(result["persona_match"])

        except:

            result["persona_match"] = 0.90

        try:

            result["confidence"] = float(result["confidence"])

        except:

            result["confidence"] = 0.90

        return result


# --------------------------------------------------
# TEST
# --------------------------------------------------

if __name__ == "__main__":

    analyzer = ContextAnalyzer()

    persona = {

        "role": "Doctor",

        "goal": "Help patients"

    }

    tests = [

        "Hello doctor",

        "I have diabetes",

        "I have fever",

        "Can I take insulin?",

        "Can you explain mathematics?",

        "What should I eat?"

    ]

    for message in tests:

        print("\n========================")
        print(message)
        print("========================")

        result = analyzer.analyze(

            persona,

            message

        )

        print(

            json.dumps(

                result,

                indent=4

            )

        )