// =======================================================
// SPASM++ Chat Application
// =======================================================

const sendBtn = document.getElementById("sendBtn");
const messageBox = document.getElementById("message");
const chatArea = document.getElementById("chat-area");
const newChatBtn = document.getElementById("newChatBtn");

// =========================================
// Event Listeners
// =========================================

// Send button
sendBtn.addEventListener("click", sendMessage);

// Enter key
messageBox.addEventListener("keypress", function (event) {

    if (event.key === "Enter") {

        event.preventDefault();

        sendMessage();

    }

});

// New Chat
if (newChatBtn) {

    newChatBtn.addEventListener("click", newChat);

}

// =========================================
// Send Message
// =========================================

function sendMessage() {

    const message = messageBox.value.trim();

    if (message === "") return;

    // Add User Message
    addUserMessage(message);

    // Clear Input
    messageBox.value = "";

    // Show temporary thinking message
    const thinking = addAssistantMessage("Thinking...");

    // Send request to Flask
    fetch("/chat", {

        method: "POST",

        headers: {

            "Content-Type": "application/json"

        },

        body: JSON.stringify({

            message: message,

            role: document.getElementById("role").value,

            tone: document.getElementById("tone").value,

            goal: document.getElementById("goal").value

        })

    })

    .then(response => {

        if (!response.ok) {

            throw new Error("Server Error");

        }

        return response.json();

    })

    .then(data => {

        // Remove Thinking...
        thinking.remove();

        // Assistant Reply
        addAssistantMessage(data.reply);

        // Update Analysis
        updateAnalysis(data.analysis);

    })

    .catch(error => {

        console.error(error);

        thinking.remove();

        addAssistantMessage("⚠ Unable to connect to Flask.");

    });

}

// =========================================
// Add User Message
// =========================================

function addUserMessage(message) {

    const div = document.createElement("div");

    div.className = "user";

    div.innerHTML = `

        <div class="name">

            You

        </div>

        <div class="bubble">

            ${message}

        </div>

    `;

    chatArea.appendChild(div);

    scrollBottom();

}

// =========================================
// Add Assistant Message
// =========================================

function addAssistantMessage(message) {

    const div = document.createElement("div");

    div.className = "assistant";

    div.innerHTML = `

        <div class="name">

            Assistant

        </div>

        <div class="bubble">

            ${message}

        </div>

    `;

    chatArea.appendChild(div);

    scrollBottom();

    return div;

}

// =========================================
// Update Live Analysis
// =========================================

function updateAnalysis(analysis) {

    if (!analysis) return;

    document.getElementById("category").innerText =
        analysis.category;

    document.getElementById("personaScore").style.width =
        (analysis.persona_relevance * 100) + "%";

    document.getElementById("personaScore").innerText =
        analysis.persona_relevance.toFixed(2);

    document.getElementById("taskScore").style.width =
        (analysis.task_relevance * 100) + "%";

    document.getElementById("taskScore").innerText =
        analysis.task_relevance.toFixed(2);

    document.getElementById("emotionScore").style.width =
        (analysis.emotion * 100) + "%";

    document.getElementById("emotionScore").innerText =
        analysis.emotion.toFixed(2);

    document.getElementById("recencyScore").style.width =
        (analysis.recency * 100) + "%";

    document.getElementById("recencyScore").innerText =
        analysis.recency.toFixed(2);

    document.getElementById("status").innerHTML =
        "🟢 Persona Stable";

}

// =========================================
// New Chat
// =========================================

function newChat() {

    chatArea.innerHTML = `

        <div class="assistant">

            <div class="name">

                Assistant

            </div>

            <div class="bubble">

                Welcome to SPASM++.<br><br>

                Please choose a persona and start chatting.

            </div>

        </div>

    `;

    document.getElementById("category").innerText = "--";

    document.getElementById("personaScore").style.width = "0%";
    document.getElementById("personaScore").innerText = "0.00";

    document.getElementById("taskScore").style.width = "0%";
    document.getElementById("taskScore").innerText = "0.00";

    document.getElementById("emotionScore").style.width = "0%";
    document.getElementById("emotionScore").innerText = "0.00";

    document.getElementById("recencyScore").style.width = "0%";
    document.getElementById("recencyScore").innerText = "0.00";

    document.getElementById("status").innerHTML =
        "🟢 Waiting...";

}

// =========================================
// Auto Scroll
// =========================================

function scrollBottom() {

    chatArea.scrollTop = chatArea.scrollHeight;

}