import os
import sys

sys.path.append(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

from scripts.llm import generate


class PersonaRepairEngine:

    def __init__(self, threshold=0.90, max_attempts=2):

        self.threshold = threshold
        self.max_attempts = max_attempts

    def repair(
        self,
        persona,
        user_message,
        response,
        stability_score
    ):
        """
        Returns:
            repaired_response,
            repaired(bool),
            attempts
        """

        # Already stable
        if stability_score >= self.threshold:

            return response, False, 0

        repaired_response = response

        for attempt in range(self.max_attempts):

            prompt = f"""
You are a Persona Repair Engine.

Your job is to rewrite the assistant response
without changing the answer.

Maintain the persona strictly.

Persona

Role:
{persona["role"]}

Tone:
{persona["tone"]}

Goal:
{persona["goal"]}

User Message

{user_message}

Current Response

{repaired_response}

Instructions

1. Preserve the same meaning.
2. Do NOT contradict the persona.
3. Keep the same topic.
4. Use the required tone.
5. Be more consistent with the persona.
6. Do not mention you are repairing anything.

Return ONLY the improved response.
"""

            repaired_response = generate(prompt)

        return repaired_response, True, self.max_attempts


# ---------------------------------------------------
# TEST
# ---------------------------------------------------

if __name__ == "__main__":

    engine = PersonaRepairEngine()

    persona = {

        "role": "Doctor",

        "tone": "Professional",

        "goal": "Help patients."

    }

    response, repaired, attempts = engine.repair(

        persona,

        "I have diabetes.",

        "Eat healthy.",

        0.45

    )

    print("\nRepaired :", repaired)
    print("Attempts :", attempts)
    print("\nResponse\n")
    print(response)