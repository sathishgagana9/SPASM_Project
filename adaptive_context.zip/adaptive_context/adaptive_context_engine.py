import os
import sys
import json

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from context_analyzer import ContextAnalyzer
from importance_scorer import ImportanceScorer
from dependency_analyzer import DependencyAnalyzer
from novelty_detector import NoveltyDetector
from risk_analyzer import RiskAnalyzer
from context_selector import AdaptiveContextSelector
from conversation_graph import SemanticMemoryGraph
from graph_retriever import GraphRetriever
from prompt_builder import PromptBuilder
from persona_stability_checker import PersonaStabilityChecker
from persona_repair_engine import PersonaRepairEngine
from decision_engine import DecisionEngine
from response_optimizer import ResponseOptimizer

from scripts.llm import generate


class AdaptiveContextEngine:

    def __init__(self):

        # ------------------------------------
        # Core Modules
        # ------------------------------------

        self.context_analyzer = ContextAnalyzer()

        self.importance_scorer = ImportanceScorer()

        self.dependency_analyzer = DependencyAnalyzer()

        self.novelty_detector = NoveltyDetector()

        self.risk_analyzer = RiskAnalyzer()

        self.selector = AdaptiveContextSelector()

        # ------------------------------------
        # Semantic Memory
        # ------------------------------------

        self.graph = SemanticMemoryGraph()

        # ------------------------------------
        # Prompt Builder
        # ------------------------------------

        self.prompt_builder = PromptBuilder()

        # ------------------------------------
        # SPASM++
        # ------------------------------------

        self.persona_checker = PersonaStabilityChecker()

        self.persona_repair = PersonaRepairEngine(

            threshold=0.90,

            max_attempts=3

        )

        self.decision_engine = DecisionEngine()

        self.response_optimizer = ResponseOptimizer()

        # ------------------------------------
        # Conversation History
        # ------------------------------------

        self.conversation = []

        self.analysis_history = []

        self.importance_history = []

        self.risk_history = []