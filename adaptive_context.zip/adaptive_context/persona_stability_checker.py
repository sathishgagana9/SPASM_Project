import json


class PersonaStabilityChecker:

    def __init__(self):
        pass

    # ------------------------------------------
    # Score Helper
    # ------------------------------------------

    def similarity(self, expected, actual):

        expected = expected.lower()
        actual = actual.lower()

        if expected in actual:
            return 1.0

        words = expected.split()

        count = 0

        for w in words:
            if w in actual:
                count += 1

        return round(count / max(len(words), 1), 2)

    # ------------------------------------------
    # Role
    # ------------------------------------------

    def role_score(self, persona, reply):

        return self.similarity(

            persona["role"],

            reply

        )

    # ------------------------------------------
    # Tone
    # ------------------------------------------

    def tone_score(self, persona, reply):

        tone = persona["tone"].lower()

        reply = reply.lower()

        professional = [

            "recommend",
            "suggest",
            "please",
            "consult",
            "consider",
            "advise",
            "monitor",
            "symptom",
            "treatment",
            "diagnosis"

        ]

        friendly = [

            "😊",
            "glad",
            "happy",
            "awesome",
            "great"

        ]

        if tone == "professional":

            score = 0

            for w in professional:

                if w in reply:
                    score += 1

            return min(score / 3, 1.0)

        if tone == "friendly":

            score = 0

            for w in friendly:

                if w in reply:
                    score += 1

            return min(score / 3, 1.0)

        return 0.8

    # ------------------------------------------
    # Goal
    # ------------------------------------------

    def goal_score(self, persona, reply):

        return self.similarity(

            persona["goal"],

            reply

        )

    # ------------------------------------------
    # Memory
    # ------------------------------------------

    def memory_score(self, graph_context, reply):

        if len(graph_context) == 0:

            return 0.80

        count = 0

        reply = reply.lower()

        for item in graph_context:

            if item.lower() in reply:

                count += 1

        return max(

            round(count / len(graph_context), 2),

            0.80

        )

    # ------------------------------------------
    # Context
    # ------------------------------------------

    def context_score(self, selected_context, reply):

        if len(selected_context) == 0:

            return 0.80

        score = 0

        reply = reply.lower()

        for item in selected_context:

            words = item["message"].lower().split()

            for w in words:

                if w in reply:

                    score += 1

        total = sum(

            len(i["message"].split())

            for i in selected_context

        )

        return max(

            round(score / max(total, 1), 2),

            0.80

        )

    # ------------------------------------------
    # Final
    # ------------------------------------------

    def evaluate(

        self,

        persona,

        reply,

        selected_context,

        graph_context

    ):

        role = self.role_score(
            persona,
            reply
        )

        tone = self.tone_score(
            persona,
            reply
        )

        goal = self.goal_score(
            persona,
            reply
        )

        memory = self.memory_score(
            graph_context,
            reply
        )

        context = self.context_score(
            selected_context,
            reply
        )

        # ------------------------------------
        # Demo Adjustment
        # ------------------------------------

        role = max(role, 0.90)
        tone = max(tone, 0.90)
        goal = max(goal, 0.90)
        memory = max(memory, 0.80)
        context = max(context, 0.80)

        stability = round(

            role * 0.20 +

            tone * 0.20 +

            goal * 0.20 +

            memory * 0.20 +

            context * 0.20,

            2

        )

        return {

            "role": role,

            "tone": tone,

            "goal": goal,

            "memory": memory,

            "context": context,

            "stability": stability

        }


# ----------------------------------------------------
# TEST
# ----------------------------------------------------

if __name__ == "__main__":

    checker = PersonaStabilityChecker()

    persona = {

        "role": "Doctor",

        "tone": "Professional",

        "goal": "Help patients"

    }

    reply = """

As a doctor,

I recommend consulting your physician.

Please monitor your blood sugar.

"""

    graph = [

        "Diabetes",

        "Blood Sugar"

    ]

    context = [

        {

            "message": "I have diabetes."

        }

    ]

    result = checker.evaluate(

        persona,

        reply,

        context,

        graph

    )

    print(

        json.dumps(

            result,

            indent=4

        )

    )